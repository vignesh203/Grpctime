# gPRCDateTimeJava
Sample gRPC application in Java
